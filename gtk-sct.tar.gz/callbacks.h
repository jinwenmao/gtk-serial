#include <gtk/gtk.h>


void
on_comboboxentry1_changed              (GtkComboBox     *combobox,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

gboolean
on_window1_destroy_event               (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_comboboxentry1_changed              (GtkComboBox     *combobox,
                                        gpointer         user_data);

void
on_comboboxentry2_changed              (GtkComboBox     *combobox,
                                        gpointer         user_data);

void
on_comboboxentry4_changed              (GtkComboBox     *combobox,
                                        gpointer         user_data);

void
on_comboboxentry3_changed              (GtkComboBox     *combobox,
                                        gpointer         user_data);
